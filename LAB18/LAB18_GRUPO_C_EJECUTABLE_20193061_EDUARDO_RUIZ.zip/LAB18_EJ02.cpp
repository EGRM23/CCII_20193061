#include <iostream>
using namespace std;

//EDUARDO GERMAN RUIZ MAMANI
//CUI 20193061

template <int R>
struct Fibonacci {
	enum { fibo = Fibonacci<R-1>::fibo + Fibonacci<R-2>::fibo };
};

template <>
struct Fibonacci<1> {
	enum { fibo = 1 };
};

template <>
struct Fibonacci<2> {
	enum { fibo = 1 };
};

int main(int argc, char *argv[]) {
	int f = Fibonacci<10>::fibo;
	cout << f << endl;
	return 0;
}

