#ifndef PATO_H
#define PATO_H
#include "Ave.h"

class Pato : public Ave {
public:
	Pato(string);
	~Pato();
};

#endif

