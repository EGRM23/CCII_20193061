#include "Ganso.h"

Ganso :: Ganso(string n) : Ave(n) {
	tipo = "Ganso";
	volar = true;
}

Ganso :: ~Ganso() {}

