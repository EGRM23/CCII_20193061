#ifndef GANSO_H
#define GANSO_H
#include "Ave.h"

class Ganso : public Ave {
public:
	Ganso(string);
	~Ganso();
};

#endif

