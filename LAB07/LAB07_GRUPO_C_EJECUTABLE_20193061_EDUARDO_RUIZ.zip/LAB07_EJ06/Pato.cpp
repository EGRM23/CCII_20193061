#include "Pato.h"

Pato :: Pato(string n) : Ave(n) {
	tipo = "Pato";
	volar = true;
}

Pato :: ~Pato() {}
