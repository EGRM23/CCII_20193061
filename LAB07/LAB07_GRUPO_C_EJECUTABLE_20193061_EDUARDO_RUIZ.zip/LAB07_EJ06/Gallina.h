#ifndef GALLINA_H
#define GALLINA_H
#include "Ave.h"

class Gallina : public Ave {
public:
	Gallina(string);
	~Gallina();
};

#endif

