#include "Gallina.h"

Gallina :: Gallina(string n) : Ave(n) {
	tipo = "Gallina";
	volar = false;
}

Gallina :: ~Gallina() {}

